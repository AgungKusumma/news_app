package com.agungkusuma.news_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
